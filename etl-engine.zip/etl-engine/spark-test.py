from pyspark.sql import SparkSession
from delta import configure_spark_with_delta_pip

# Create a Spark session with Delta Lake configuration
builder = SparkSession.builder \
    .appName("etl-engine-local") \
    .master("local[*]") \
    .config("spark.hadoop.validateOutputSpecs", "false") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .config("spark.hadoop.fs.defaultFS", "file:///") \
    .config("spark.sql.warehouse.dir", "/tmp/spark-warehouse") \
    .config("spark.hadoop.io.native.lib.available", "false") \

# Configure Spark with Delta Lake
spark = configure_spark_with_delta_pip(builder).getOrCreate()

delta_path = r"C:\tmp\delta\customers"

# Create a Delta table
df = spark.createDataFrame([(1, "Alice"), (2, "Bob")], ["id", "name"])
df.write.format("delta").mode("overwrite").save(delta_path)

# Read Delta table
df2 = spark.read.format("delta").load(delta_path)
df2.show()