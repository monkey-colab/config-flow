from engine import Engine
from spark import create_local_spark

spark = create_local_spark()
engine = Engine(spark)


# Run bronze task
#engine.run_task_file("bronze_question_answers.yaml")

# Run silver task
engine.run_task_file("silver_question_answers.yaml")
