Got it ✅ — let’s write **detailed documentation** for every part of the pipeline config and extensions.
This will be a **comprehensive reference manual** for config authors and developers.

---

# 📘 Pipeline Config Specification & Extension Guide (Detailed)

---

## 1. Introduction

This framework defines **config-driven Spark pipelines** for Databricks.
The goal:

* Configs are **requirement-oriented** (not code-heavy).
* Tasks can handle **multiple sources** and **multiple targets**.
* Supports **filters, joins, transforms, constraints, deletes, and listeners**.
* Extensible via **factories** (custom filters, transforms, constraints, listeners).
* Errors are reported with **config file name and line number**.

Pipelines are organized in **stages**:

* **Bronze** → raw ingestion.
* **Silver** → cleaned, conformed data.
* **Gold** → curated for analytics/ML.

---

## 2. Top-Level Structure

### Schema

```yaml
name: <pipeline_name>
stage: bronze | silver | gold
tasks:
  - <task_definition>
```

### Explanation

* **name** → unique pipeline identifier.
* **stage** → logical data tier (`bronze`, `silver`, `gold`).
* **tasks** → list of tasks to run in this pipeline.

---

## 3. Tasks

A **task** describes how data moves from **sources → targets**.

### Schema

```yaml
tasks:
  - name: <task_name>
    description: <optional_description>
    sources: [...]
    joins: [...]
    targets: [...]
    deletes: {...}
    listeners: {...}
```

### Explanation

* **name** → unique task name.
* **description** → human-readable explanation.
* **sources** → one or more data sources.
* **joins** → if multiple sources, define join logic.
* **targets** → one or more data targets.
* **deletes** → rules for propagating deletes.
* **listeners** → hooks for custom pre/post actions.

---

## 4. Sources

### Schema

```yaml
sources:
  - name: customers
    type: table | file | folder
    table: <db.table_name>     # if type=table
    path: <storage_path>       # if type=file|folder
    format: parquet | csv | json | delta
    filters:
      - <filter_definition>
    transforms:
      - <transform_definition>
```

### Explanation

* **name** → reference name for this source.
* **type** → input type: table, file, or folder.
* **table** → full table name if source is a table.
* **path** → file/folder path if applicable.
* **format** → input format (`parquet`, `csv`, `json`, `delta`, etc.).
* **filters** → conditions to subset rows at source level.
* **transforms** → preprocessing steps, all **transient** (not written, only intermediate).

---

## 5. Joins

### Schema

```yaml
joins:
  - left: customers
    right: orders
    type: inner | left | right | full
    keys:
      - left_field: customer_id
        right_field: customer_id
```

### Explanation

* **left** → name of left source.
* **right** → name of right source.
* **type** → join type (`inner`, `left`, `right`, `full`).
* **keys** → mapping of join fields between left and right.

> 🔹 If there’s only one source, no join is required.

---

## 6. Targets

### Schema

```yaml
targets:
  - name: customers_silver
    type: table | file
    mode: append | overwrite | merge
    table: <db.table_name>
    path: <storage_path>
    filters:
      - <filter_definition>
    transforms:
      - <transform_definition>
    constraints:
      - <constraint_definition>
```

### Explanation

* **name** → reference name for this target.
* **type** → output type: table or file.
* **mode** → Spark write mode:

  * `append` → add new records.
  * `overwrite` → replace.
  * `merge` → upsert (requires keys, not shown in minimal schema).
* **table** / **path** → output location.
* **filters** → row-level filtering before writing.
* **transforms** → transformations applied at target level.
* **constraints** → validation and enforcement before writing.

---

## 7. Filters

### Schema

```yaml
filters:
  - field: <field_name>
    op: equals | not_equals | in | custom
    value: <single_value>        # if applicable
    values: [<val1>, <val2>]     # if applicable
```

### Explanation

* **field** → column name to filter on.
* **op** → operation:

  * `equals` → `col == value`
  * `not_equals` → `col != value`
  * `in` → `col IN (values)`
  * custom ops can be registered.
* **value/values** → operand(s).

---

## 8. Transforms

### Schema

```yaml
transforms:
  - target: <new_field>
    source: <existing_field>     # optional
    op: copy | lower | upper | parse_json | custom
    params: {...}                # optional
    transient: true | false
```

### Explanation

* **target** → output column.
* **source** → input column (defaults to same as target if omitted).
* **op** → operation name.
* **params** → additional arguments for operation.
* **transient**:

  * `true` → field exists only for intermediate use.
  * `false` → field is persisted in target.

---

## 9. Constraints

### Schema

```yaml
constraints:
  - field: <field_name>
    op: not_null | range | regex | custom
    params: {...}                 # op-specific
    on_failure:
      action: apply_default | quarantine | log | skip_row | fail_task
      default: <value>            # if apply_default
      quarantine_table: <table>   # if quarantine
```

### Explanation

* **field** → column under validation.
* **op** → constraint type.
* **params** → additional arguments (e.g., `{min: 18, max: 120}`).
* **on\_failure.action**:

  * `apply_default` → replace with default.
  * `quarantine` → send to quarantine table.
  * `log` → log failure.
  * `skip_row` → drop row.
  * `fail_task` → fail the whole task.

---

## 10. Deletes

### Schema

```yaml
deletes:
  propagate: true | false
  params:
    - field: <field_name>
      op: equals | not_null | custom
      value: <val>
```

### Explanation

* **propagate** → whether deletes cascade downstream.
* **params** → conditions for deletion. Uses the same **filter registry**.

---

## 11. Listeners

### Schema

```yaml
listeners:
  pre_read: ["custom_fn1", "custom_fn2"]
  post_write: ["custom_fn3"]
```

### Explanation

* Lifecycle hooks where user-defined functions can run:

  * `pre_read`, `post_read`
  * `pre_transform`, `post_transform`
  * `pre_validate`, `post_validate`
  * `pre_write`, `post_write`
* Each entry is a list of registered function names.

---

## 12. Custom Extensions

The framework uses **factories** for extensibility.

### Filters

```python
@register_filter("starts_with")
def filter_starts_with(df, spec):
    return df.filter(F.col(spec.field).startswith(spec.value))
```

### Transforms

```python
@register_transform("parse_json")
def transform_parse_json(df, spec):
    return df.withColumn(spec.target, F.from_json(F.col(spec.source), spec.params["schema"]))
```

### Constraints

```python
@register_constraint("regex")
def constraint_regex(df, spec):
    return df.filter(F.col(spec.field).rlike(spec.params["pattern"]))
```

### Listeners

```python
def audit_start(context):
    print(f"Starting task {context['task_name']}...")

def notify_completion(context):
    print(f"Completed task {context['task_name']}")
```

---

## 13. Error Reporting

Every config entry carries:

* **File name** → `__file__`
* **Line number** → `__line__`

Errors are reported as:

```
❌ Unknown transform op: parse_email_domain
   in file: customer_pipeline.yaml, line: 42
   path: tasks[0].targets[0].transforms[1]
```

---

## 14. Summary

* **Pipeline** → composed of tasks.
* **Task** → sources, joins, targets, deletes, listeners.
* **Source** → may have filters & transient transforms.
* **Target** → may have filters, transforms, constraints.
* **Joins** → define how multiple sources merge.
* **Filters** → subset rows (source/target/deletes).
* **Transforms** → modify or create fields (source/target).
* **Constraints** → enforce data quality at write.
* **Deletes** → propagate logical deletions.
* **Listeners** → lifecycle hooks.
* **Factories** → allow new operations without modifying engine.
* **Errors** → always show file name + line number + path.

---

👉 Would you like me to now generate a **single comprehensive YAML config example (bronze → silver → gold)** that demonstrates **every feature** (joins, filters, constraints, deletes, listeners, custom ops)?
