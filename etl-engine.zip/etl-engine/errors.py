# etl_engine/errors.py
class ConfigError(Exception):
    def __init__(self, message: str, file: str = None, line: int = None):
        self.file = file
        self.line = line
        super().__init__(f"{file or '<config>'}:{line or '?'} - {message}")

class ExecutionError(Exception):
    def __init__(self, message: str, file: str = None, line: int = None):
        self.file = file
        self.line = line
        super().__init__(f"{file or '<exec>'}:{line or '?'} - {message}")
