# etl_engine/config.py
from typing import List, Optional, Union, Dict, Any
from pydantic import BaseModel, Field, ValidationError
import yaml
from yaml_loader import load_yaml_with_lines

# -- Models --
class TransformModel(BaseModel):
    target: str
    source: Optional[str] = None
    op: Optional[str] = None
    params: Dict[str, Any] = {}
    transient: bool = False
    used_in_join: Optional[bool] = False

class FilterModel(BaseModel):
    field: str
    op: str
    value: Optional[Any] = None
    values: Optional[List[Any]] = None

class ConstraintFailureModel(BaseModel):
    action: str  # apply_default | quarantine | skip_row | log | fail_task
    default: Optional[Any] = None
    quarantine_table: Optional[str] = None

class ConstraintModel(BaseModel):
    field: str
    op: str
    params: Dict[str, Any] = {}
    on_failure: ConstraintFailureModel

class SourceModel(BaseModel):
    name: str
    type: str  # file | table
    format: Optional[str] = None
    path: Optional[str] = None
    table: Optional[str] = None
    mode: Optional[str] = "record"  # file | record
    filters: List[FilterModel] = []
    transforms: List[TransformModel] = []

class JoinKeyModel(BaseModel):
    left_field: str
    right_field: str

class JoinModel(BaseModel):
    left: str
    right: str
    type: Optional[str] = "inner"  # inner | left | right | outer
    keys: List[JoinKeyModel]
    join_after_transforms: Optional[bool] = None

class TargetModel(BaseModel):
    name: str
    table: str
    mode: Optional[str] = "append"
    primary_key: Optional[Union[str, List[str]]] = None
    update_strategy: Optional[str] = "merge"  # merge | replace
    propagate_deletes_from: Optional[str] = None
    filters: List[FilterModel] = []
    transforms: List[TransformModel] = []
    constraints: List[ConstraintModel] = []

class TaskConfig(BaseModel):
    name: str
    desc: Optional[str] = None
    stage: str  # bronze | silver | gold
    sources: List[SourceModel]
    joins: List[JoinModel] = []
    targets: List[TargetModel] = []

# -- Loader wrapper --
def load_task_config(filename: str) -> TaskConfig:
    """
    Load YAML with line/file metadata and validate with Pydantic.
    Raises ValueError with file/line annotated messages on validation errors.
    """
    raw = load_yaml_with_lines(filename)
    try:
        task = TaskConfig(**raw)
        return task
    except ValidationError as ve:
        # Try to map each pydantic error to a likely node with __file__/__line__
        messages = []
        for err in ve.errors():
            loc = list(err.get("loc", []))
            # fallback to top-level file/line
            file_ = raw.get("__file__", filename) if isinstance(raw, dict) else filename
            line_ = raw.get("__line__", "?") if isinstance(raw, dict) else "?"
            # not easy to map nested loc to node without walking raw; report top-level location
            messages.append(f"{file_}:{line_} - {err.get('msg')} (path: {'.'.join(map(str,loc))})")
        raise ValueError("Config validation errors:\n" + "\n".join(messages)) from ve
    except Exception as e:
        file_ = raw.get("__file__", filename) if isinstance(raw, dict) else filename
        line_ = raw.get("__line__", "?") if isinstance(raw, dict) else "?"
        raise RuntimeError(f"Error parsing config {file_}:{line_} - {e}") from e
