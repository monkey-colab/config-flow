import yaml
from typing import Any, Dict

class LineNumberLoader(yaml.SafeLoader):
    def __init__(self, stream, filename: str):
        super().__init__(stream)
        self._filename = filename

    def construct_mapping(self, node, deep=False) -> Dict[str, Any]:
        mapping = super().construct_mapping(node, deep=deep)
        mapping["__file__"] = getattr(self, "_filename", "<unknown>")
        mapping["__line__"] = node.start_mark.line + 1
        return mapping

def load_yaml_with_lines(filename: str) -> Dict[str, Any]:
    with open(filename, "r", encoding="utf-8") as f:
        loader = lambda stream: LineNumberLoader(stream, filename)
        data = yaml.load(f, Loader=loader)
    return data
