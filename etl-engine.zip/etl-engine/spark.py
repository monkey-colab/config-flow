# etl_engine/utils/spark.py
from pyspark.sql import SparkSession
import os

def create_local_spark(
    app_name: str = "etl_engine_local",
    local_cores: int | None = None,
    warehouse_dir: str | None = None,
) -> SparkSession:
    """
    Create a local SparkSession for ETL engine.
    - Configures warehouse location explicitly (important on Windows)
    - Allows controlling number of local cores
    """
    # Default warehouse dir
    if warehouse_dir is None:
        warehouse_dir = os.path.abspath("spark-warehouse").replace("\\", "/")

    builder = (
        SparkSession.builder
        .appName(app_name)
        .config("spark.sql.shuffle.partitions", "8")
        .config("spark.sql.warehouse.dir", warehouse_dir)
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
    )

    # Local master setup
    if local_cores:
        builder = builder.master(f"local[{local_cores}]")
    else:
        builder = builder.master("local[*]")

    spark = builder.getOrCreate()
    return spark