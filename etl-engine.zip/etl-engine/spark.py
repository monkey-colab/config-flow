# etl_engine/utils/spark.py
from pyspark.sql import SparkSession

def create_local_spark(app_name: str = "etl_engine_local", local_cores: int = None, delta: bool = False) -> SparkSession:
    builder = SparkSession.builder.appName(app_name)
    if local_cores:
        builder = builder.master(f"local[{local_cores}]")
    else:
        builder = builder.master("local[*]")

    if delta:
        builder = builder.config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
                         .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
    builder = builder.config("spark.sql.shuffle.partitions", "8")
    return builder.getOrCreate()
