from typing import Callable, Dict
from .executor import Executor


class Engine:
    def __init__(self, spark):
        self.spark = spark
        self.executor = Executor(spark, self)
        # registries
        self.transforms: Dict[str, Callable] = {}
        self.filters: Dict[str, Callable] = {}
        self.constraints: Dict[str, Callable] = {}
        self.parsers: Dict[str, Callable] = {}
        self.listeners: Dict[str, list] = {"pre": [], "post": []}

    # -------- Registration --------
    def register_transform(self, name: str):
        def wrapper(func: Callable):
            self.transforms[name] = func
            return func
        return wrapper

    def register_filter(self, name: str):
        def wrapper(func: Callable):
            self.filters[name] = func
            return func
        return wrapper

    def register_constraint(self, name: str):
        def wrapper(func: Callable):
            self.constraints[name] = func
            return func
        return wrapper

    def register_parser(self, name: str):
        def wrapper(func: Callable):
            self.parsers[name] = func
            return func
        return wrapper

    def register_listener(self, when: str):
        def wrapper(func: Callable):
            self.listeners.setdefault(when, []).append(func)
            return func
        return wrapper

    # -------- Run Task --------
    def run_task(self, config, raw_yaml: str, config_file: str):
        for listener in self.listeners.get("pre", []):
            listener(config)

        result = self.executor.run_task(config, raw_yaml, config_file)

        for listener in self.listeners.get("post", []):
            listener(config, result)

        return result
