# etl_engine/engine.py
import traceback
from typing import Callable
from pyspark.sql import SparkSession, functions as F, types as T  # Import F globally

from config import load_task_config, load_yaml_with_lines
from registry import Registry
from executor import Executor
from errors import ExecutionError
from delta.tables import DeltaTable

class Engine:
    def __init__(self, spark: SparkSession):
        self.spark = spark
        self.registry = Registry()
        self.executor = Executor(spark, self.registry)

        # register common built-ins on registry (wrappers)
        self._register_default_ops()

    # ---------- registration decorators (Option 2)
    def register_transform(self, name: str):
        return self.registry.register_transform(name)

    def register_filter(self, name: str):
        return self.registry.register_filter(name)

    def register_constraint(self, name: str):
        return self.registry.register_constraint(name)

    def register_constraint_action(self, name: str):
        return self.registry.register_constraint_action(name)

    def register_parser(self, fmt: str):
        return self.registry.register_parser(fmt)

    def register_listener(self, stage: str):
        return self.registry.register_listener(stage)

    # ---------- load + run
    def run_task_file(self, config_file: str):
        # loads + validates config (pydantic) and then runs
        try:
            raw = load_yaml_with_lines(config_file)
            task = load_task_config(config_file)
            return self._run_task(task, raw, config_file)
        except Exception as e:
            raise ExecutionError(f"Failed to load/validate config {config_file}: {e}")

    def _run_task(self, task, raw_yaml, config_file: str):
        try:
            # Orchestrate via executor but also trigger listeners from registry
            # Pre-run listeners (optional)
            for fn in self.registry.get_listeners("pre_run"):
                try:
                    fn(None, {"task": task.name, "config_file": config_file})
                except Exception:
                    print("pre_run listener error:", traceback.format_exc())

            # Use executor to perform the work
            result = self.executor.run_task(task, raw_yaml, config_file)

            # Post-run listeners
            for fn in self.registry.get_listeners("post_run"):
                try:
                    fn(None, {"task": task.name, "config_file": config_file})
                except Exception:
                    print("post_run listener error:", traceback.format_exc())

            return result
        except Exception as e:
            raise ExecutionError(f"Error running task {task.name}: {e}")

    # ---------- default builtin registrations for convenience
    def _register_default_ops(self):
        # transforms
        @self.register_transform("lower")
        def _lower(df, tr):
            return df.withColumn(tr.target, F.lower(F.col(tr.source or tr.target)))

        @self.register_transform("upper")
        def _upper(df, tr):
            return df.withColumn(tr.target, F.upper(F.col(tr.source or tr.target)))

        @self.register_transform("explode")
        def _explode(df, tr):
            return df.withColumn(tr.target, F.explode(F.col(tr.source)))

        # filters
        @self.register_filter("equals")
        def _equals(df, f):
            return df.filter(F.col(f.field) == f.value)

        @self.register_filter("not_equals")
        def _not_equals(df, f):
            return df.filter(F.col(f.field) != f.value)

        @self.register_filter("regex")
        def _regex(df, f):
            return df.filter(F.col(f.field).rlike(f.value))

        # constraints (ops and actions)
        @self.register_constraint("not_null")
        def _not_null(df, c):
            # produce mask column
            mask_col = f"_mask_{c.field}_notnull"
            return df.withColumn(mask_col, F.col(c.field).isNotNull())

        @self.register_constraint_action("apply_default")
        def _apply_default(df, c):
            mask_col = next((col for col in df.columns if col.startswith(f"_mask_{c.field}_")), None)
            if mask_col:
                return df.withColumn(c.field, F.when(F.col(mask_col), F.col(c.field)).otherwise(F.lit(c.on_failure.default))).drop(mask_col)
            return df

        @self.register_constraint_action("skip_row")
        def _skip_row(df, c):
            mask_col = next((col for col in df.columns if col.startswith(f"_mask_{c.field}_")), None)
            if mask_col:
                return df.filter(F.col(mask_col)).drop(mask_col)
            return df

        @self.register_constraint_action("quarantine")
        def _quarantine(df, c):
            mask_col = next((col for col in df.columns if col.startswith(f"_mask_{c.field}_")), None)
            if mask_col:
                bad = df.filter(~F.col(mask_col))
                if c.on_failure.quarantine_table:
                    bad.write.format("delta").mode("append").saveAsTable(c.on_failure.quarantine_table)
                return df.filter(F.col(mask_col)).drop(mask_col)
            return df

        @self.register_transform("parse_json")
        def _parse_json(df, tr):
            return df.withColumn("parsed", F.from_json(F.col(tr.source or tr.target).cast("string"), T.StringType()))


