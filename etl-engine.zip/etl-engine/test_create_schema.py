from pyspark.sql import SparkSession
from delta.tables import DeltaTable

def initialize_tables():
    spark = SparkSession.builder \
        .appName("etl_engine_local") \
        .master("local[*]") \
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
        .getOrCreate()

    # Create schemas
    for schema in ["bronze", "silver", "gold"]:
        spark.sql(f"CREATE SCHEMA IF NOT EXISTS spark_catalog.{schema}")

    # Bronze table with explicit path
    bronze_path = "C:/Users/Gaurav/etl-engine/spark-warehouse/bronze.db/questions_raw"
    if not DeltaTable.isDeltaTable(spark, bronze_path):
        spark.sql(f"""
            CREATE TABLE IF NOT EXISTS spark_catalog.bronze.questions_raw
            USING delta
            LOCATION '{bronze_path}'
            AS SELECT CAST(NULL AS BINARY) AS content,
                      CAST(NULL AS STRING) AS path,
                      CAST(NULL AS STRING) AS filename,
                      CAST(NULL AS TIMESTAMP) AS modified_time,
                      CAST(NULL AS BIGINT) AS size
        """)
    # Silver tables
    silver_questions_path = "C:/Users/Gaurav/etl-engine/spark-warehouse/silver.db/questions"
    if not DeltaTable.isDeltaTable(spark, silver_questions_path):
        spark.sql(f"""
            CREATE TABLE IF NOT EXISTS spark_catalog.silver.questions
            USING delta
            LOCATION '{silver_questions_path}'
            AS SELECT CAST(NULL AS STRING) AS question_id,
                      CAST(NULL AS STRING) AS question_text
        """)

    silver_answers_path = "C:/Users/Gaurav/etl-engine/spark-warehouse/silver.db/answers"
    if not DeltaTable.isDeltaTable(spark, silver_answers_path):
        spark.sql(f"""
            CREATE TABLE IF NOT EXISTS spark_catalog.silver.answers
            USING delta
            LOCATION '{silver_answers_path}'
            AS SELECT CAST(NULL AS STRING) AS answer_id,
                      CAST(NULL AS STRING) AS answer_text,
                      CAST(NULL AS DOUBLE) AS answer_score,
                      CAST(NULL AS STRING) AS question_id
        """)

    # Validate tables
    for schema, tables in {"bronze": ["questions_raw"], "silver": ["questions","answers"]}.items():
        tables_created = spark.sql(f"SHOW TABLES IN spark_catalog.{schema}").collect()
        table_names = [row.tableName for row in tables_created]
        for table in tables:
            if table not in table_names:
                raise Exception(f"Table spark_catalog.{schema}.{table} was not created successfully.")

    print("Schemas and tables initialized successfully.")

    # Describe table
    spark.sql("DESCRIBE EXTENDED spark_catalog.bronze.questions_raw").show(truncate=False)

if __name__ == "__main__":
    initialize_tables()
