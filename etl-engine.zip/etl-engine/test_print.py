from pyspark.sql import SparkSession

# Create Spark session with Delta support
spark = SparkSession.builder \
    .appName("print_bronze_questions") \
    .master("local[*]") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

bronze_path = r"C:/Users/Gaurav/etl-engine/spark-warehouse/bronze.db/questions_raw"
df = spark.read.format("delta").load(bronze_path)
df.show(truncate=False)

# Show the first 20 rows
df.show(truncate=False)

# Optionally print schema
df.printSchema()