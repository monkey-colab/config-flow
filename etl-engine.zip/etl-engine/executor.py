from pyspark.sql import DataFrame
from pyspark.sql.functions import col
import yaml
from .models import TaskConfig


class Executor:
    def __init__(self, spark, engine):
        self.spark = spark
        self.engine = engine
        self.target_map = {}  # name → path

    def run_task(self, config: TaskConfig, raw_yaml: str, config_file: str):
        # ---- Load sources ----
        dfs = {}
        for src in config.sources:
            if src.type == "file":
                df = self.spark.read.format(src.format).load(src.path)
            elif src.type == "table":
                df = self.spark.read.format("delta").load(src.table)
            else:
                raise ValueError(f"Unknown source type {src.type} in {config_file}")

            # Apply source transforms
            df = self.apply_transforms(df, src.transforms, config_file, raw_yaml)
            dfs[src.name] = df

        # ---- Apply joins ----
        df_final = None
        if config.joins:
            for join in config.joins:
                left = dfs[join.left]
                right = dfs[join.right]
                conds = [left[k["left_field"]] == right[k["right_field"]] for k in join.keys]
                df_final = left.join(right, conds, join.type)
        else:
            # Single source fallback
            if len(dfs) == 1:
                df_final = list(dfs.values())[0]

        # ---- Write targets ----
        for tgt in config.targets:
            df_out = df_final
            df_out = self.apply_filters(df_out, tgt.filters, config_file, raw_yaml)
            df_out = self.apply_transforms(df_out, tgt.transforms, config_file, raw_yaml)
            self.apply_constraints(df_out, tgt.constraints, config_file, raw_yaml)
            self.write_target(df_out, tgt, config_file)

        return True

    # ----------------------------
    # Apply filters
    # ----------------------------
    def apply_filters(self, df: DataFrame, filters, config_file, raw_yaml):
        if not filters:
            return df
        for f in filters:
            fn = self.engine.filters.get(f.op)
            if not fn:
                raise ValueError(f"Unknown filter {f.op} in {config_file}")
            df = fn(df, f)
        return df

    # ----------------------------
    # Apply transforms
    # ----------------------------
    def apply_transforms(self, df: DataFrame, transforms, config_file, raw_yaml):
        if not transforms:
            return df
        for t in transforms:
            if t.op:
                fn = self.engine.transforms.get(t.op)
                if not fn:
                    raise ValueError(f"Unknown transform {t.op} in {config_file}")
                df = fn(df, t)
            else:
                df = df.withColumnRenamed(t.source or t.target, t.target)
        return df

    # ----------------------------
    # Apply constraints
    # ----------------------------
    def apply_constraints(self, df: DataFrame, constraints, config_file, raw_yaml):
        if not constraints:
            return
        for c in constraints:
            fn = self.engine.constraints.get(c.op)
            if not fn:
                raise ValueError(f"Unknown constraint {c.op} in {config_file}")
            df = fn(df, c)
        return

    # ----------------------------
    # Write target + delete propagation
    # ----------------------------
    def write_target(self, df: DataFrame, target, config_file, delta_available=True):
        target_path = target.table
        self.target_map[target.name] = target_path

        if target.propagate_deletes_to and target.primary_key:
            pk = target.primary_key
            try:
                existing_df = self.spark.read.format("delta").load(target_path)
            except Exception:
                existing_df = None
            if existing_df is not None:
                current_keys = [r[pk] for r in df.select(pk).collect()]
                deleted_keys = existing_df.select(pk).where(~col(pk).isin(current_keys))
                for child in target.propagate_deletes_to:
                    if child not in self.target_map:
                        continue
                    child_path = self.target_map[child]
                    try:
                        child_df = self.spark.read.format("delta").load(child_path)
                        child_df_filtered = child_df.join(deleted_keys, child_df[pk] == deleted_keys[pk], "left_anti")
                        child_df_filtered.write.format("delta").mode("overwrite").save(child_path)
                    except Exception:
                        continue

        df.write.format("delta").mode(target.mode).save(target_path)
