# etl_engine/executor.py
import glob
import zipfile
import os
import datetime
import traceback
from functools import reduce
from typing import Dict, Any, List, Tuple

from pyspark.sql import DataFrame, SparkSession, functions as F, types as T

from config import TaskConfig, SourceModel, TargetModel, TransformModel, FilterModel, ConstraintModel
from errors import ExecutionError
from registry import Registry

from typing import TYPE_CHECKING
import os
from delta.tables import DeltaTable


class Executor:
    def __init__(self, spark: SparkSession, registry: Registry):
        self.spark = spark
        self.registry = registry

    # read source (file/table)
    def read_source(self, src: SourceModel):
        if src.type == "table":
            path = self._resolve_table(src.table)

            try:
                return self.spark.table(src.table)
            except Exception:
                if os.path.exists(path):
                    return self.spark.read.format("delta").load(path)
                else:
                    raise ExecutionError(f"Table '{src.table}' not found in catalog or path: {path}")
        if src.type == "file":
            if src.mode == "file":
                return self._read_raw_files(src.path)
            # structured
            parser = self.registry.get_parser(src.format)
            if parser:
                return parser(self.spark, src.path, {})
            # built-in fallback
            if src.format == "jsonl":
                return self.spark.read.json(src.path)
            if src.format == "csv":
                return self.spark.read.option("header", True).csv(src.path)
            if src.format == "parquet":
                return self.spark.read.parquet(src.path)
            return self.spark.read.format(src.format or "text").load(src.path)
        raise ExecutionError(f"Unknown source type: {src.type}")

    def _read_raw_files(self, pattern: str):
        rows = []
        for f in glob.glob(pattern):
            try:
                if zipfile.is_zipfile(f):
                    with zipfile.ZipFile(f, "r") as z:
                        for entry in z.namelist():
                            content = z.read(entry)
                            stat = os.stat(f)
                            rows.append({
                                "content": content,
                                "path": f"{f}/{entry}",
                                "filename": entry,
                                "modified_time": datetime.datetime.fromtimestamp(stat.st_mtime),
                                "size": len(content)
                            })
                else:
                    stat = os.stat(f)
                    with open(f, "rb") as fh:
                        content = fh.read()
                    rows.append({
                        "content": content,
                        "path": f,
                        "filename": os.path.basename(f),
                        "modified_time": datetime.datetime.fromtimestamp(stat.st_mtime),
                        "size": stat.st_size
                    })
            except Exception as e:
                raise ExecutionError(f"Error reading file {f}: {e}")
        if not rows:
            schema = T.StructType([
                T.StructField("content", T.BinaryType(), True),
                T.StructField("path", T.StringType(), True),
                T.StructField("filename", T.StringType(), True),
                T.StructField("modified_time", T.TimestampType(), True),
                T.StructField("size", T.LongType(), True),
            ])
            return self.spark.createDataFrame([], schema)
        return self.spark.createDataFrame(rows)

    # apply transform using registry
    def apply_transform(self, df: DataFrame, tr: TransformModel, raw_yaml: dict, config_file: str):
        try:
            if tr.op is None:
                src = tr.source or tr.target
                return df.withColumn(tr.target, F.col(src))
            op = self.registry.get_transform(tr.op)
            if not op:
                raise ExecutionError(f"Unknown transform op '{tr.op}' in {config_file}")
            return op(df, tr)
        except Exception as e:
            raise ExecutionError(f"Transform '{tr.target}' failed: {e}")

    # apply filter using registry
    def apply_filter(self, df: DataFrame, f: FilterModel, raw_yaml: dict, config_file: str):
        try:
            op = self.registry.get_filter(f.op)
            if not op:
                raise ExecutionError(f"Unknown filter op '{f.op}' in {config_file}")
            return op(df, f)
        except Exception as e:
            raise ExecutionError(f"Filter '{f.field}' failed: {e}")

    # apply constraint: run constraint op, then run action (both from registry)
    def apply_constraint(self, df: DataFrame, c: ConstraintModel, raw_yaml: dict, config_file: str):
        try:
            op = self.registry.get_constraint(c.op)
            if not op:
                raise ExecutionError(f"Unknown constraint op '{c.op}' in {config_file}")
            df_with_mask = op(df, c)
            mask_col = next((col for col in df_with_mask.columns if col.startswith(f"_mask_{c.field}_")), None)
            if not mask_col:
                raise ExecutionError(f"Constraint op '{c.op}' did not create mask column for field '{c.field}'")
            action = c.on_failure.action
            action_fn = self.registry.get_constraint_action(action)
            if not action_fn:
                raise ExecutionError(f"Unknown constraint action '{action}' in {config_file}")
            return action_fn(df_with_mask, c)
        except Exception as e:
            raise ExecutionError(f"Constraint '{c.field}' failed: {e}")

    # build base DF for target
    def build_target_base(self, tgt: TargetModel, dfs: Dict[str, DataFrame], task: TaskConfig, config_file: str):
        # inspect transform.source fields to find used source names (source.field)
        used_sources = []
        for tr in tgt.transforms:
            s = tr.source
            if s and "." in s:
                candidate = s.split(".")[0]
                if candidate in dfs and candidate not in used_sources:
                    used_sources.append(candidate)
            elif s and s in dfs:
                if s not in used_sources:
                    used_sources.append(s)
        if not used_sources:
            # fallback: if only one source, return it; otherwise join using join definitions
            if len(dfs) == 1:
                return next(iter(dfs.values()))
            # attempt to merge sources present in task.joins in sequence
            # naive approach: return first source
            return next(iter(dfs.values()))
        base = dfs[used_sources[0]]
        for src_name in used_sources[1:]:
            other = dfs[src_name]
            common = set(base.columns).intersection(set(other.columns))
            if not common:
                base = base.crossJoin(other)
            else:
                cond = reduce(lambda a, b: a & b, [base[c] == other[c] for c in common])
                base = base.join(other, on=cond, how="inner")
        return base

    def _resolve_table(self, table: str) -> str:
        """Resolve catalog name and filesystem path for a managed table."""
        warehouse_dir = self.spark.conf.get("spark.sql.warehouse.dir")
        db, tbl = table.split(".")
        path = os.path.join(warehouse_dir, f"{db}.db", tbl)

        # Normalize Windows path: remove 'file:/' prefix if present
        if path.startswith("file:/") or path.startswith("file:\\"):
            path = path.replace("file:/", "", 1).replace("file:\\", "", 1)

        # Convert to absolute path (Windows-friendly)
        path = os.path.abspath(path)
        return path

    def write_target(self, df, tgt, config_file: str):
        try:
            table = tgt.table
            pk = tgt.primary_key
            update_strategy = tgt.update_strategy or "merge"
            propagate_from = tgt.propagate_deletes_from
            mode = tgt.mode or "append"

            # Resolve catalog and path
            path = self._resolve_table(table)

            # Windows-safe Delta write: check if path exists
            if DeltaTable.isDeltaTable(self.spark, path):
                tgt_dt = DeltaTable.forPath(self.spark, path)
            else:
                # First write to path
                df.write.format("delta").mode(mode).save(path)
                # Register table in catalog
                self.spark.sql(f"""
                    CREATE TABLE IF NOT EXISTS {table}
                    USING DELTA
                    LOCATION '{path}'
                """)
                tgt_dt = DeltaTable.forPath(self.spark, path)

            # Apply merge / replace strategies
            if update_strategy == "replace":
                if pk is None:
                    tgt_dt.delete()
                    df.write.format("delta").mode("append").save(path)
                else:
                    keys = pk if isinstance(pk, list) else [pk]
                    src_keys = df.select(*keys).distinct()
                    tgt_dt.alias("tgt").merge(
                        src_keys.alias("src"),
                        " AND ".join([f"tgt.{k}=src.{k}" for k in keys])
                    ).whenMatchedDelete().execute()
                    df.write.format("delta").mode("append").save(path)
            else:  # merge
                if pk is None:
                    df.write.format("delta").mode("append").save(path)
                else:
                    keys = pk if isinstance(pk, list) else [pk]
                    cond = " AND ".join([f"tgt.{k}=src.{k}" for k in keys])
                    tgt_dt.alias("tgt").merge(df.alias("src"), cond) \
                        .whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

            # Propagate deletes
            if propagate_from:
                src_catalog, src_path = self._resolve_table(propagate_from)
                if DeltaTable.isDeltaTable(self.spark, src_path) and pk:
                    src_dt = DeltaTable.forPath(self.spark, src_path)
                    tgt_dt.alias("target").merge(
                        src_dt.toDF().alias("src"),
                        " AND ".join([f"target.{k}=src.{k}" for k in keys])
                    ).whenNotMatchedDelete().execute()

        except Exception as e:
            raise ExecutionError(f"Write target '{tgt.name}' failed: {e}")
    
    def run_task(self, task, raw_yaml, config_file):
        """
        Execute a full TaskConfig.
        """
        # 1️⃣ Read all sources into dict
        source_dfs = {}
        for src in task.sources:
            df = self.read_source(src)
            # Apply source-level transforms
            for tr in src.transforms:
                df = self.apply_transform(df, tr, raw_yaml, config_file)
            source_dfs[src.name] = df

        # 2️⃣ Apply joins if any
        for join in task.joins:
            left_df = source_dfs[join.left]
            right_df = source_dfs[join.right]
            join_expr = None
            for key in join.keys:
                cond = left_df[key.left_field] == right_df[key.right_field]
                join_expr = cond if join_expr is None else (join_expr & cond)
            joined_df = left_df.join(right_df, on=join_expr, how=join.type)
            # Replace left in dict with joined result
            source_dfs[join.left] = joined_df

        # 3️⃣ Write to each target
        for tgt in task.targets:
            # Determine base DF for this target
            base_df = self.build_target_base(tgt, source_dfs, task, config_file)

            # Apply target-level transforms
            for tr in tgt.transforms:
                base_df = self.apply_transform(base_df, tr, raw_yaml, config_file)

            # Apply target-level filters
            for f in tgt.filters:
                base_df = self.apply_filter(base_df, f, raw_yaml, config_file)

            # Apply constraints
            for c in tgt.constraints:
                base_df = self.apply_constraint(base_df, c, raw_yaml, config_file)

            # Write target
            self.write_target(base_df, tgt, config_file)

        return True