# etl_engine/registry.py
from typing import Callable, Dict, List, Any

class Registry:
    def __init__(self):
        self.transforms: Dict[str, Callable] = {}
        self.filters: Dict[str, Callable] = {}
        self.constraints: Dict[str, Callable] = {}
        self.constraint_actions: Dict[str, Callable] = {}
        self.parsers: Dict[str, Callable] = {}
        self.listeners: Dict[str, List[Callable]] = {}

    # Transform registration decorator
    def register_transform(self, name: str):
        def decorator(fn):
            self.transforms[name] = fn
            return fn
        return decorator

    def register_filter(self, name: str):
        def decorator(fn):
            self.filters[name] = fn
            return fn
        return decorator

    def register_constraint(self, name: str):
        def decorator(fn):
            self.constraints[name] = fn
            return fn
        return decorator

    def register_constraint_action(self, name: str):
        def decorator(fn):
            self.constraint_actions[name] = fn
            return fn
        return decorator

    def register_parser(self, fmt: str):
        def decorator(fn):
            self.parsers[fmt] = fn
            return fn
        return decorator

    def register_listener(self, stage: str):
        def decorator(fn):
            self.listeners.setdefault(stage, []).append(fn)
            return fn
        return decorator

    # Getter helpers
    def get_transform(self, name: str):
        return self.transforms.get(name)

    def get_filter(self, name: str):
        return self.filters.get(name)

    def get_constraint(self, name: str):
        return self.constraints.get(name)

    def get_constraint_action(self, name: str):
        return self.constraint_actions.get(name)

    def get_parser(self, fmt: str):
        return self.parsers.get(fmt)

    def get_listeners(self, stage: str):
        return self.listeners.get(stage, [])
